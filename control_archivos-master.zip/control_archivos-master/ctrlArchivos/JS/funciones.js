﻿function mostrar_ocultar(id) {
    $('#'+id).toogleClass("ocultar");
}